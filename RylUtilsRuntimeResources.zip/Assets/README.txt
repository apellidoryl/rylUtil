﻿Optional third-party app icons are not included in this public bundle.
RylUtils uses text glyphs when app icons are unavailable.
